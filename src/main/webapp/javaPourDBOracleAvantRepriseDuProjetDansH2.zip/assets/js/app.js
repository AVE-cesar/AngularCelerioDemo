var app = angular.module("mainApp", ["ngResource",/* for REST WS calls */
					 "ui.router",
					 "pascalprecht.translate", /* for label translation */
					 'mgcrea.ngStrap', /* for drawer/aside, see:  http://mgcrea.github.io/angular-strap/ */
					 'ngAnimate'
                                         ]);
